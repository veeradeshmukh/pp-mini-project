# SoBo Bappa Map

A college project: an interactive map of Ganpati mandals in South Mumbai, with filters,
reviews, photo uploads and a form to add new mandals.

**Stack:** Python (Flask + SQLite) for the database and server; HTML, CSS and JavaScript
for the website; Leaflet + OpenStreetMap for the map (free, no API key, no login).

## Run it

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. The first run creates `mandals.db` and seeds 10 mandals.
To start fresh, stop the server and delete `mandals.db`.

## How it fits together

```
browser (HTML/CSS/JS)  --fetch()-->  app.py (Flask routes)  -->  database.py (SQL)  -->  mandals.db
```

| File | Job |
|------|-----|
| `database.py` | Tables, seed data, every SQL query |
| `app.py` | Routes, input validation, photo upload checks |
| `templates/index.html` | Home page: map, filters, cards |
| `templates/contribute.html` | "Add / Review Mandal" page with its three options |
| `static/js/common.js` | Shared helpers (HTML escaping, Google Maps link, map setup) |
| `static/js/main.js` | Markers, hover popup, filters, details dialog |
| `static/js/contribute.js` | Pin picker and the three forms |

## IMPORTANT: verify the data before you submit

- **Pin positions are approximate.** I could not look up exact coordinates, so each seeded pin
  sits at roughly locality level (it may be a few hundred metres off). The popup says
  "Pin is approximate" for these. To fix one: in Google Maps right-click the exact spot, click
  the coordinates to copy them, paste into `SEED_MANDALS` in `database.py`, delete `mandals.db`
  and rerun. (Later you could add a column update instead of re-seeding.)
- The **"Open in Google Maps" button uses a name search** for seeded mandals, so it should land
  on the real place even where our pin is off. Please click each one and check.
- **Ratings, crowd and parking for seeded mandals are placeholders**, not survey results.
  They are flagged `is_sample` and are not counted as reviews. Replace them with real reviews
  (ask classmates to review) before presenting.
- Establishment years appear only where a published source was found; others are blank.
- **Geography:** "South Mumbai" is defined loosely. Lalbaug, Parel and Chinchpokli are often
  grouped with it, but strictly they are central. GSB Seva Mandal (King's Circle) is a top
  mandal but sits north of the map limits, so it is not included. Change `BOUNDS` in `app.py`
  if your course defines the area differently.
- **Timing:** Ganeshotsav 2026 has already ended, so this works best as a reference guide for
  next year's festival.

## Design decisions worth explaining in your viva

- **Hover popups:** a popup opens on `mouseover` and stays until you click the map or another pin,
  so you can move onto the button. Phones have no hover, so tapping a pin works too.
- **Map restricted to South Mumbai:** `maxBounds` + `maxBoundsViscosity` in `common.js`. The same
  box is checked on the server in `app.py`, because anything the browser does can be bypassed.
- **No location permission:** we never call the browser's geolocation API.
- **"Geotracker":** this is a map of fixed pins, not live tracking. Real tracking would need
  GPS data streamed from devices, which is out of scope here.
- **Security basics you already have:** parameterised SQL (no injection), HTML escaping of all
  user text (no XSS), upload type checked by file contents, 5 MB cap, random file names.

## Ideas to extend (pick one or two, not all)

1. **Average-rating fairness:** show a "Bayesian" average so one 5-star review does not outrank
   fifty 4-star ones. Good statistics practice.
2. **Moderation:** add an `approved` column; new mandals and photos appear only after you approve
   them in a small `/admin` page. This is the most realistic improvement.
3. **More filters:** eco-friendly idol, public transport access, queue time, family-friendly,
   idol height, established year. Each is one column, one form field and one filter.
4. **Route planner:** pick 3-4 mandals and open one multi-stop Google Maps link.
5. **Spam control:** rate-limit submissions (Flask-Limiter) or add a simple captcha.
6. **Charts:** a page showing crowd vs rating, using Chart.js.
7. **Hosting:** deploy free on PythonAnywhere or Render. Note that SQLite and uploaded files on
   free hosts can be wiped, so mention that limitation if you deploy.
8. **Tests:** turn the checks used to verify this project into `pytest` tests.

## What to learn from this project

- SQL: `JOIN`, `GROUP BY`, `AVG`, foreign keys, constraints.
- REST-style APIs: GET vs POST, status codes (201, 400, 404, 409, 413).
- Validation on both client and server, and why the server is the one that counts.
- `fetch()` and async/await in JavaScript; DOM updates without a framework.
- Using an open-source library (Leaflet) and reading its documentation.
- Respecting licences: OpenStreetMap needs the attribution shown in the map corner, and its
  public tile server is meant for light use like a college demo.
